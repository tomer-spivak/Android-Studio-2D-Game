package tomer.spivak.androidstudio2dgame.logic.modelEnums;

public enum Direction {
    DOWNLEFT,
    DOWNRIGHT,
    UPLEFT,
    UPRIGHT
}
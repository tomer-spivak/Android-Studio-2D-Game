package tomer.spivak.androidstudio2dgame.logic.modelEnums;
public enum GameStatus {
    PLAYING,
    WON,
    LOST
}
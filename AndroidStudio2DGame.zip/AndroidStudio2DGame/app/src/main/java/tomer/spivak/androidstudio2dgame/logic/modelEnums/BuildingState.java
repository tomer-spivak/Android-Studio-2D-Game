package tomer.spivak.androidstudio2dgame.logic.modelEnums;

public enum BuildingState {
    IDLE, HURT, ATTACKING
}
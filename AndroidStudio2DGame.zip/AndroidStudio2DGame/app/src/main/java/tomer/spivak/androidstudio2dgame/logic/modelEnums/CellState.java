package tomer.spivak.androidstudio2dgame.logic.modelEnums;
public enum CellState {
    NORMAL,
    BURNT,
    ENEMYDEATH1,
    ENEMYDEATH2,
    ENEMYDEATH3,
    EXPLODE,
    SPAWN
}
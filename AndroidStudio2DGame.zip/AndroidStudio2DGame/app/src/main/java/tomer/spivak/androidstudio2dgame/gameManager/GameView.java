package tomer.spivak.androidstudio2dgame.gameManager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

import tomer.spivak.androidstudio2dgame.GridView.CustomGridView;
import tomer.spivak.androidstudio2dgame.GridView.TouchHandler;
import tomer.spivak.androidstudio2dgame.R;
import tomer.spivak.androidstudio2dgame.buildingHelper.BuildingView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, TouchHandler.TouchHandlerListener {

    private GameLoop gameLoop;

    private CustomGridView gridView;

    private TouchHandler touchHandler;

    private Context context;

    private ArrayList<BuildingView> buildingsViewsArrayList = new ArrayList<>();;

    public BuildingView selectedBuilding;

    public GameView(Context context) {
        super(context);

        this.context = context;

        SurfaceHolder surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);

        gameLoop = new GameLoop(this, surfaceHolder);

        touchHandler = new TouchHandler(context, this);

        gridView = new CustomGridView(context);
        Log.d("gridView", gridView + "");
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        gridView.initInstance(20, 20);

        gameLoop.startLoop();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return touchHandler.onTouchEvent(event) || super.onTouchEvent(event);
    }

    @Override
    public void onScale(float scaleFactor, float focusX, float focusY) {
        gridView.updateScale(scaleFactor, focusX, focusY);
    }

    @Override
    public void onScroll(float deltaX, float deltaY) {
        if (deltaX < 100 && deltaY < 100)
            gridView.updatePosition(deltaX, deltaY);
    }

    @Override
    public void onBoxClick(float x, float y) {
        Log.d("boxClick", x + " " + y);
        Point cellCenterPoint = gridView.getSelectedCell(x, y);
        Log.d("boxClick", cellCenterPoint.toString());
        if (selectedBuilding != null && isCellEmpty(cellCenterPoint) ) {
            Log.d("boxClick", selectedBuilding.toString());
            selectedBuilding.setPoint(cellCenterPoint);
            addBuildingView(selectedBuilding);
        }
    }

    private boolean isCellEmpty(Point cellCenterPoint) {
        for (BuildingView buildingView : buildingsViewsArrayList){
            if (buildingView.getPoint() != null && buildingView.getPoint().equals(cellCenterPoint)){
                return false;
            }
        }
        return true;
    }


    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void draw(Canvas canvas) {
        Log.d("canvas", "canvas: " + canvas);
        super.draw(canvas);

        if (canvas != null) {
            // Remove canvas.save() and translate since we're using grid position updates
            drawFPS(canvas);
            drawUPS(canvas);
            gridView.draw(canvas);

            for (BuildingView buildingView : buildingsViewsArrayList){

                ImageView imageView = buildingView.getView(); // Ensure this returns a valid ImageView

                // Set the position of the ImageView
                imageView.setX(buildingView.getPoint().x);
                imageView.setY(buildingView.getPoint().y);

                Drawable drawable = imageView.getDrawable();
                if (drawable != null) {
                    // Ensure the drawable is properly sized and drawn on the canvas
                    drawable.setBounds(
                            (int) buildingView.getPoint().x,
                            (int) buildingView.getPoint().y,
                            (int) (buildingView.getPoint().x + imageView.getWidth()),
                            (int) (buildingView.getPoint().y + imageView.getHeight())
                    );
                    Log.d("boxClick", drawable.getBounds().toString());
                    drawable.draw(canvas);
                }
                Log.d("boxClick", buildingView.getPoint().toString());
                Log.d("boxClick", buildingView.getView().getDrawable() + "");
                Log.d("boxClick", buildingView.getView().toString());



                Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                        drawable.getIntrinsicHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas bitmapCanvas = new Canvas(bitmap);
                drawable.setBounds(0, 0, bitmapCanvas.getWidth(), bitmapCanvas.getHeight());
                drawable.draw(bitmapCanvas);

// Then draw the bitmap
                canvas.drawBitmap(bitmap, buildingView.getPoint().x, buildingView.getPoint().y, null);




            }
        }
    }

    public void drawUPS(Canvas canvas) {
        String averageUPS = Double.toString(gameLoop.getAverageUPS());
        Paint paint = new Paint();
        int color = ContextCompat.getColor(getContext(), R.color.yellow);
        paint.setColor(color);
        paint.setTextSize(30);
        // Draw UI elements at fixed positions
        canvas.drawText("UPS: " + averageUPS, 100, 100, paint);
    }

    public void drawFPS(Canvas canvas) {
        String averageFPS = Double.toString(gameLoop.getAverageFPS());
        Paint paint = new Paint();
        int color = ContextCompat.getColor(getContext(), R.color.red);
        paint.setColor(color);
        paint.setTextSize(30);
        // Draw UI elements at fixed positions
        canvas.drawText("FPS: " + averageFPS, 100, 200, paint);
    }

    public void update() {
        // Add any update logic here
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
    }


    public void addBuildingView(BuildingView selectedBuildingView) {
        buildingsViewsArrayList.add(selectedBuildingView);
        Log.d("boxClick", buildingsViewsArrayList.toString());


    }
}
package tomer.spivak.androidstudio2dgame.logic.modelEnums;

public enum DifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
package tomer.spivak.androidstudio2dgame.modelObjects;

public interface IDamager {
    void dealDamage(IDamageable target); // Called when entity attacks
}

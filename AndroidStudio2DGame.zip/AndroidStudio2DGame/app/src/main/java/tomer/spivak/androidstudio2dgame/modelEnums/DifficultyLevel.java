package tomer.spivak.androidstudio2dgame.modelEnums;

public enum DifficultyLevel {
    EASY,
    MEDIUM,
    HARD,
}

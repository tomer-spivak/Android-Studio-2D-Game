package tomer.spivak.androidstudio2dgame.modelEnums;

public enum CellState {
    NORMAL,
    BURNT,
    ENEMYDEATH1,
    ENEMYDEATH2,
    ENEMYDEATH3
}

package tomer.spivak.androidstudio2dgame.gameActivity;

public interface OnItemClickListener {
    void onBuildingRecyclerViewItemClick(String buildingImageURL, int position);
}
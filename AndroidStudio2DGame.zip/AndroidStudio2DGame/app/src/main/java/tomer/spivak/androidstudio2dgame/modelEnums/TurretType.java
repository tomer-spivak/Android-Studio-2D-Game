package tomer.spivak.androidstudio2dgame.modelEnums;

public enum TurretType {
    LIGHTNINGTOWER
}

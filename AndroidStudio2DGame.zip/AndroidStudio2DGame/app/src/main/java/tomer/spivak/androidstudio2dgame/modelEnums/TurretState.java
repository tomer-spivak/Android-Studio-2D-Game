package tomer.spivak.androidstudio2dgame.modelEnums;

public enum TurretState {
    IDLE,
    ATTACKING,
    HURT
}

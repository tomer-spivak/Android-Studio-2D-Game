package tomer.spivak.androidstudio2dgame.modelEnums;

public enum BuildingState {
    IDLE,
    HURT,
    ATTACKING
}

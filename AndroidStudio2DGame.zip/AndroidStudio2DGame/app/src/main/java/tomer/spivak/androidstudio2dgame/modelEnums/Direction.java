package tomer.spivak.androidstudio2dgame.modelEnums;

public enum Direction {
    DOWNLEFT, DOWNRIGHT, UPLEFT, UPRIGHT
}

package tomer.spivak.androidstudio2dgame.modelEnums;

public enum EnemyState {
    IDLE,
    HURT,
    ATTACKING1,
    ATTACKING2,
    ATTACKING3,
    ATTACKING4
}

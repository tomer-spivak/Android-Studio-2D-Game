package tomer.spivak.androidstudio2dgame.modelEnums;

public enum EnemyState {
    IDLE,
    MOVING,
    ATTACKING,
    HURT
}

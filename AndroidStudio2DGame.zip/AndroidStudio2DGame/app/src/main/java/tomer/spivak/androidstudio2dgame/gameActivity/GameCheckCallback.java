package tomer.spivak.androidstudio2dgame.gameActivity;

public interface GameCheckCallback {
    void onCheckCompleted(boolean gameExists);
}

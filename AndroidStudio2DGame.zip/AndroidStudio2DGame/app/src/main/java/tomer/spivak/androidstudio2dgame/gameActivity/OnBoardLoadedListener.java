package tomer.spivak.androidstudio2dgame.gameActivity;

import tomer.spivak.androidstudio2dgame.model.Cell;

// Define a callback interface
public interface OnBoardLoadedListener {
    void onBoardLoaded(Cell[][] board);
}


